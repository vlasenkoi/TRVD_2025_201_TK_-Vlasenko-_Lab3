const User = require('../models/user');

exports.getAllUsers = async (req, res) => {
  const users = await User.find();
  res.render('pages/users', { users });
};

exports.createUserForm = (req, res) => {
  res.render('pages/createUser');
};

exports.createUser = async (req, res) => {
  const { name, email } = req.body;
  await User.create({ name, email });
  res.redirect('/users');
};

exports.deleteUser = async (req, res) => {
  await User.findByIdAndDelete(req.params.id);
  res.redirect('/users');
};
