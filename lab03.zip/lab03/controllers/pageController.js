exports.homePage = (req, res) => {
  res.render('pages/index');
};

exports.aboutPage = (req, res) => {
  res.render('pages/about');
};
